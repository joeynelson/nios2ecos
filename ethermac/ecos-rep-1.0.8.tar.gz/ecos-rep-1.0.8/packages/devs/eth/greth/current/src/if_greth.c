//==========================================================================
//
//      dev/if_greth.c
//
//      Ethernet device driver for Gaisler Research's ethernet mac
//
//==========================================================================
//####ECOSGPLCOPYRIGHTBEGIN####
// -------------------------------------------
// This file is part of eCos, the Embedded Configurable Operating System.
// Copyright (C) 1998, 1999, 2000, 2001, 2002 Red Hat, Inc.
// Copyright (C) 2003 Nick Garnett 
// Copyright (C) 2004 Andrew Lunn
//
// eCos is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 or (at your option) any later version.
//
// eCos is distributed in the hope that it will be useful, but WITHOUT ANY
// WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with eCos; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
//
// As a special exception, if other files instantiate templates or use macros
// or inline functions from this file, or you compile this file and link it
// with other works to produce a work based on this file, this file does not
// by itself cause the resulting work to be covered by the GNU General Public
// License. However the source code for this file must still be made available
// in accordance with section (3) of the GNU General Public License.
//
// This exception does not invalidate any other reasons why a work based on
// this file might be covered by the GNU General Public License.
//
// Alternative licenses for eCos may be arranged by contacting Red Hat, Inc.
// at http://sources.redhat.com/ecos/ecos-license/
// -------------------------------------------
//####ECOSGPLCOPYRIGHTEND####
//==========================================================================
//#####DESCRIPTIONBEGIN####
//
// Author(s):    Gaisler Research, (Kristoffer Carlsson <kristoffer@gaisler.com>)
// Contributors: 
// Date:         2005-12-06
// Purpose:      
// Description:  
// Notes:        
//####DESCRIPTIONEND####
//
//==========================================================================


#include <pkgconf/system.h>
#ifdef CYGPKG_IO_ETH_DRIVERS
#include <pkgconf/io_eth_drivers.h>
#endif
#include <pkgconf/devs_eth_greth.h>

#include <cyg/infra/cyg_type.h>
#include <cyg/hal/hal_arch.h>
#include <cyg/hal/hal_intr.h>
#include <cyg/hal/hal_diag.h>
#include <cyg/hal/hal_io.h>
#include <cyg/infra/cyg_ass.h>
#include <cyg/infra/diag.h>
#include <cyg/hal/drv_api.h>
#include <cyg/io/eth/netdev.h>
#include <cyg/io/eth/eth_drv.h>
#include <cyg/hal/hal_cache.h>

#ifdef CYGPKG_NET
#include <pkgconf/net.h>
#include <cyg/kernel/kapi.h>
#include <net/if.h>  
#endif

#ifdef CYGPKG_KERNEL
#include <cyg/kernel/kapi.h>
#endif

#if CYGNUM_DEVS_ETH_GRETH_DEV_COUNT > 1
#error Only 1 mac at a time supported yet
#endif

/*#define DEBUG_GRETH*/

#ifdef DEBUG_GRETH

#define DEBUG_RX_PACKETS 0
#define DEBUG_TX_PACKETS 0
#define os_printf diag_printf
#define db_printf diag_printf

#else

#define DEBUG_RX_PACKETS 0
#define DEBUG_TX_PACKETS 0
#define os_printf(fmt,...)
#define db_printf(fmt,...)

#endif

#define MACADDR0 macaddr[0]
#define MACADDR1 macaddr[1]
#define MACADDR2 macaddr[2]
#define MACADDR3 macaddr[3]
#define MACADDR4 macaddr[4]
#define MACADDR5 macaddr[5]

#include <sys/mbuf.h>
#include <if_greth.h>
#include CYGDAT_DEVS_ETH_GRETH_INL
#define ALIGN_IPHDR 2

cyg_uint8 macaddr[6] = CYGPKG_DEVS_ETH_GRETH_ETH0_ESA;

#define LOAD(a,v) HAL_READ_UINT32(&(a),v);
#define SAVE(a,v) HAL_WRITE_UINT32(&(a),v);
#define REGORIN(a,v)  \
    { cyg_uint32 va;       \
      LOAD(a,va);  \
      va |= v;             \
      SAVE(a,va);  \
    }              
#define REGANDIN(a,v) \
    { cyg_uint32 va;       \
      LOAD(a,va);  \
      va &= v;             \
      SAVE(a,va);  \
    }              

static void greth_start( struct eth_drv_sc *sc, unsigned char *enaddr, int flags );
static void greth_stop( struct eth_drv_sc *sc );
static cyg_uint32 eth_isr(cyg_vector_t vector, cyg_addrword_t data);
static void eth_dsr(cyg_vector_t vector, cyg_ucount32 count, cyg_addrword_t data);

#ifndef CYGPKG_DEVS_ETH_GRETH_GBIT_ONLY
static cyg_uint8 rxbuf[GRETH_RXBD_NUM*GRETH_RX_BUF_SIZE];
static cyg_uint8 txbuf[GRETH_TXBD_NUM*GRETH_TX_BUF_SIZE];
#endif

static char rxbufr[1024*2];
static char txbufr[1024*2];

static char *almalloc(int sz)
{
        char *tmp;
        tmp = calloc(1,2*sz);
        tmp = (char *) (((int)tmp+sz) & ~(sz -1));
        return(tmp);
}

static void greth_print_packet(unsigned long addr, int len)
{
  int i;
  diag_printf("packet: addr = %x len = %d\n", (unsigned int)addr, len);
  for(i = 0; i < len; i++) {
    if(!(i % 16))
      diag_printf("\n");
    diag_printf(" %.2x", *(((unsigned char *)addr) + i));
  }
  diag_printf("\n");
  diag_printf("\n");
}

static int read_mii(int phyaddr, int addr, volatile greth_regs *regs)
{
  cyg_uint32 tmp;

  do {
    LOAD(regs->mdio, tmp);
  } while (tmp & GRETH_MII_BUSY);

  tmp = (phyaddr << 11) | ((addr&0x1F) << 6) | 2;
  SAVE(regs->mdio, tmp);
  
  do {
    LOAD(regs->mdio, tmp);
  } while (tmp & GRETH_MII_BUSY);

  if (!(tmp & GRETH_MII_NVALID)) {
    LOAD(regs->mdio, tmp);
    return (tmp>>16)&0xFFFF;
  }
  else {
    diag_printf("GRETH: failed to read mii\n");
    return (0);
  }
}

static void write_mii(int phyaddr, int addr, int data, volatile greth_regs *regs)
{
  cyg_uint32 tmp;
  do {
    LOAD(regs->mdio, tmp);
  } while (tmp & GRETH_MII_BUSY);

  tmp = ((data&0xFFFF)<<16) | (phyaddr << 11) | ((addr&0x1F) << 6) | 1;

  SAVE(regs->mdio, tmp);

  do {
    LOAD(regs->mdio, tmp);
  } while (tmp & GRETH_MII_BUSY);

}

#ifdef ETH_DRV_GET_MAC_ADDRESS
static int eth_get_mac_address(struct eth_drv_sc *sc, char *addr)
{
  greth_info *gi = (greth_info *)sc->driver_private;
  cyg_uint32 m0,m1;

  db_printf("eth_get_mac_address\n");

  LOAD(gi->regs->esa_msb, m1);
  LOAD(gi->regs->esa_lsb, m0);

  addr[0] = (m1 >> 8) & 0xff;
  addr[1] = (m1 >> 0) & 0xff;
  addr[2] = (m0 >>24) & 0xff;
  addr[3] = (m0 >>16) & 0xff;
  addr[4] = (m0 >> 8) & 0xff;
  addr[5] = (m0 >> 0) & 0xff;
  return 0;
}
#endif

#ifdef ETH_DRV_SET_MAC_ADDRESS
static int eth_set_mac_address(struct eth_drv_sc *sc, cyg_uint8 *addr)
{
  greth_info *gi = (greth_info *)sc->driver_private;

  db_printf("eth_set_mac_address\n");

  gi->esa[0] = addr[0];
  gi->esa[1] = addr[1];
  gi->esa[2] = addr[2];
  gi->esa[3] = addr[3];
  gi->esa[4] = addr[4];
  gi->esa[5] = addr[5];
  SAVE(gi->regs->esa_msb, addr[0] << 8 | addr[1]);
  SAVE(gi->regs->esa_lsb, addr[2] << 24 | addr[3] << 16 | addr[4] << 8 | addr[5]);
  return 1;
}
#endif

int greth_autoneg(greth_info *gi)
{
  int gb, fd, sp, auto_neg, tmp, tmp1, tmp2;
  int i,j;
  
  /* get phy control register default values */
  while( (tmp=read_mii(gi->phyaddr,0,gi->regs)) & 0x8000)
    ;
  
  /* reset PHY and wait for completion */
  write_mii(gi->phyaddr,0,0x8000|tmp, gi->regs);

  while( (tmp=read_mii(gi->phyaddr,0,gi->regs)) & 0x8000)
    ;
	
   /* Check if PHY is autoneg capable and then determine operating mode, 
    * otherwise force it to 10 Mbit halfduplex 
    */
  gb = 0;
  fd = 0;
  sp = 0;
  auto_neg = 0;
  if (!((tmp >> 12) & 1)) {
    write_mii(gi->phyaddr, 0, 0, gi->regs);
  } else {
    /* wait for auto negotiation to complete and then check operating mode */
    auto_neg = 1;
    i = 0;
    while (!( ((tmp=read_mii(gi->phyaddr, 1, gi->regs))>=0) && ((tmp >> 5) & 1) ) ) {
      for (j = 0; j < 10000; j++) {}
      i++;
      if (i > 3000) {
        diag_printf("Auto negotiation timed out. Selecting default config\n");
        tmp = read_mii(gi->phyaddr, 0, gi->regs);
        gb = ((tmp >> 6) & 1) && !((tmp >> 13) & 1);
        sp = !((tmp >> 6) & 1) && ((tmp >> 13) & 1);
        fd = (tmp >> 8) & 1;
        goto auto_neg_done;
      }
    }
		if( tmp < 0 ){
      return -1;
    }
    if ((tmp >> 8) & 1) {
      tmp1 = read_mii(gi->phyaddr, 9, gi->regs);
      tmp2 = read_mii(gi->phyaddr, 10, gi->regs);
      if ( (tmp1 & GRETH_MII_EXTADV_1000FD) &&
           (tmp2 & GRETH_MII_EXTPRT_1000FD)) {
        gb = 1;
        fd = 1;
      }
      if ( (tmp1 & GRETH_MII_EXTADV_1000HD) &&
           (tmp2 & GRETH_MII_EXTPRT_1000HD)) {
        gb = 1;
        fd = 0;
      }
    }
    if ((gb == 0) || ((gb == 1) && (gi->gbit == 0))) {
      tmp1 = read_mii(gi->phyaddr, 4, gi->regs);
      tmp2 = read_mii(gi->phyaddr, 5, gi->regs);
      if ( (tmp1 & GRETH_MII_100TXFD) &&
           (tmp2 & GRETH_MII_100TXFD)) {
        sp = 1;
        fd = 1;
      }
      if ( (tmp1 & GRETH_MII_100TXHD) &&
           (tmp2 & GRETH_MII_100TXHD)) {
        sp = 1;
        fd = 0;
      }
      if ( (tmp1 & GRETH_MII_10FD) &&
           (tmp2 & GRETH_MII_10FD)) {
        fd = 1;
      }
      if ((gb == 1) && (gi->gbit == 0)) {
        gb = 0;
        fd = 0;
        write_mii(gi->phyaddr, 0, sp << 13, gi->regs);
      }
    }
  }

auto_neg_done:
  diag_printf("%s GRETH Ethermac at [0x%x] irq %d. Running %d Mbps %s duplex\n", gi->gbit ? "10/100/1000":"10/100", \
                                                                            (unsigned int)(gi->regs), (unsigned int)(gi->irq), \
	                                                                          gb ? 1000:(sp ? 100:10), fd ? "full":"half");
  
  /* Read out PHY info if extended registers are available */
  if (tmp & 1) {
    tmp1 = read_mii(gi->phyaddr, 2, gi->regs);
    tmp2 = read_mii(gi->phyaddr, 3, gi->regs);
    tmp1 = (tmp1 << 6) | ((tmp2 >> 10) & 0x3F);
    tmp = tmp2 & 0xF;
                
    tmp2 = (tmp2 >> 4) & 0x3F;
    diag_printf("PHY: Vendor %x   Device %x    Revision %d\n", tmp1, tmp2, tmp);
  } else {
    diag_printf("PHY info not available\n");
  }
        
  /* set speed and duplex bits in control register */
  LOAD(gi->regs->control, tmp);
  SAVE(gi->regs->control, tmp | (gb << 8) | (sp << 7) | (fd << 4)); 

  return 0;
}

/* Calls leon eth init */
bool greth_init(struct cyg_netdevtab_entry *ndp) {
  return CYGPKG_DEVS_ETH_GRETH_INITFN(ndp);
}

/* Called from leon eth init */
void greth_device_init(struct eth_drv_sc *sc, cyg_uint32 idx, cyg_uint32 base, cyg_uint32 irq) {

  greth_info *gi = (greth_info *)sc->driver_private;
  struct bd_info *bdi = &greth_priv_array[idx]->bdi;
  int i, tmp;

  /* Set default ethernet station address. */
  gi->esa[0] = MACADDR0;
  gi->esa[1] = MACADDR1;
  gi->esa[2] = MACADDR2;
  gi->esa[3] = MACADDR3;
  gi->esa[4] = MACADDR4;
  gi->esa[5] = MACADDR5;

  gi->sc = sc;
  gi->idx = idx;
  
  gi->regs = (greth_regs *) base;
  gi->irq = irq;

  /* Reset the controller. */
  SAVE(gi->regs->control, GRETH_RESET);
  
  do {
    LOAD(gi->regs->control, tmp);
  } while (tmp & GRETH_RESET);
  
  /* Get the phy address which assumed to have been set
   * correctly with the reset value in hardware 
   */
  LOAD(gi->regs->mdio,tmp);
  gi->phyaddr = (tmp >> 11) & 0x1F;

#ifdef CYGPKG_DEVS_ETH_GRETH_GBIT
  LOAD(gi->regs->control,tmp);
  gi->gbit = (tmp>>27) & 1;
#else
  gi->gbit = 0;
#endif
  
  bdi->tx_ring =  (((unsigned int)&txbufr) + (1024-1)) & ~(1024-1) ;
  bdi->rx_ring =  (((unsigned int)&rxbufr) + (1024-1)) & ~(1024-1) ;
  SAVE(gi->regs->tx_desc_p, (cyg_uint32) bdi->tx_ring);
  SAVE(gi->regs->rx_desc_p, (cyg_uint32) bdi->rx_ring);

  /* Configure PHY  */
#if 1
#define USE_OLD_AUTONEG
#ifdef USE_OLD_AUTONEG
  write_mii(gi->phyaddr, 0, 0x8000, gi->regs); /* reset phy */
  while ( (tmp=read_mii(gi->phyaddr,0, gi->regs)) & 0x8000) 
    ;
  
  i = 0;
  if (tmp & 0x1000) { /* augo neg */
    while ( !(read_mii(gi->phyaddr,1, gi->regs) & 0x20 ) ) {
      i++;
      if (i>50000) {
	diag_printf("Auto-negotiation failed\n");
	break;
      }
    }
  }

  tmp = read_mii(gi->phyaddr,0, gi->regs);
 
  diag_printf("GRETH(%d) Ethernet %s MAC at [0x%x] irq %d. Running %d Mbps %s duplex\n", idx, gi->gbit?"10/100/1000":"10/100" , (unsigned int)(gi->regs), (unsigned int)(gi->irq), \
	                                                                              ((tmp&0x2040) == 0x2000) ? 100:10, (tmp&0x0100) ? "full":"half");
                                                                                
  if (tmp & 0x0100) {
    /* set full duplex */
    SAVE(gi->regs->control, GRETH_FD);

  }
#else
  if ( greth_autoneg(gi) )
    return;
#endif
#else
  /* Force GBit */
  SAVE(gi->regs->control, GRETH_FD | (1 << 8));
#endif
  
#ifdef CYGPKG_DEVS_ETH_GRETH_GBIT
  if ( gi->gbit ){
    /* Scatter gather is used to send packets, no 
     * memcpy to local area used.
     */
    struct mbuf *m;
    
    for(i = 0; i < GRETH_TXBD_NUM; i++) {
      SAVE(bdi->tx_ring[i].addr , 0);
    }
    
    for(i = 0; i < GRETH_RXBD_NUM; i++) {
      m=NULL;
      MGETHDR(m,M_WAIT, MT_DATA);
      if ( !m ){
        diag_printf("GRETH(%d): Failed to allocate MBUF(s)\n",gi->idx);
      }
      MCLGET(m,M_WAIT);
      m->m_data += ALIGN_IPHDR;
      
      bdi->rxmbufs[i] = m;
      
      SAVE(bdi->rx_ring[i].addr, mtod(m,unsigned int));
      
      if ( !bdi->rx_ring[i].addr ){
        diag_printf("Failed to allocate Cluster\n");
        return;
      }
    }
    
    /* Tell IP Stack about our great hardware support */
    sc->sc_arpcom.ac_if.if_hwassist |= CSUM_IP;
    sc->sc_arpcom.ac_if.if_hwassist |= CSUM_TCP;
    sc->sc_arpcom.ac_if.if_hwassist |= CSUM_UDP;
    sc->sc_arpcom.ac_if.if_hwassist |= CSUM_IP_FRAGS;
    
  }
#endif /* CYGPKG_DEVS_ETH_GRETH_GBIT */
#if defined(CYGPKG_DEVS_ETH_GRETH_GBIT) && !defined(CYGPKG_DEVS_ETH_GRETH_GBIT_ONLY)
  else
#endif
#ifndef CYGPKG_DEVS_ETH_GRETH_GBIT_ONLY
  {
    /* Initialize descriptor buffer addresses. */
    for(i = 0; i < GRETH_TXBD_NUM; i++) {
      SAVE(bdi->tx_ring[i].addr , &txbuf[i*GRETH_TX_BUF_SIZE]);
    }
    for(i = 0; i < GRETH_RXBD_NUM; i++) {
      SAVE(bdi->rx_ring[i].addr, &rxbuf[i*GRETH_RX_BUF_SIZE]);
    }  
  }
#endif

  SAVE(gi->regs->esa_msb , MACADDR0 << 8 | MACADDR1);
  SAVE(gi->regs->esa_lsb , MACADDR2 << 24 | MACADDR3 << 16 | MACADDR4 << 8 | MACADDR5);


  // Initialize upper level driver
  (sc->funs->eth_drv->init)(sc, gi->esa);
}

static void greth_start( struct eth_drv_sc *sc, unsigned char *enaddr, int flags ) {

  greth_info *gi = (greth_info *) sc->driver_private;
  struct bd_info *bdi = (struct bd_info *) &(gi->bdi);

  int i;

  if ( gi->active )
    greth_stop( sc );

  db_printf("greth_start: irq %d\n",gi->irq);
    
  bdi->rx_cur = 0;
  bdi->tx_next = 0;
  bdi->tx_last = 0;
  bdi->tx_free = GRETH_TXBD_NUM;
  SAVE(gi->regs->tx_desc_p, (cyg_uint32) bdi->tx_ring);
  SAVE(gi->regs->rx_desc_p, (cyg_uint32) bdi->rx_ring);

  for (i = 0; i < GRETH_RXBD_NUM; i++) {
    REGORIN(bdi->rx_ring[i].stat, GRETH_BD_EN | GRETH_BD_IE); 
  }
  REGORIN(bdi->rx_ring[GRETH_RXBD_NUM-1].stat, GRETH_BD_WR); 

  /* Install our interrupt handler. */
  cyg_drv_interrupt_create(gi->irq,
                           0,                  // Priority - unused
                           (CYG_ADDRWORD)sc,   // Data item passed to ISR & DSR
                           eth_isr,            // ISR
#ifdef CYGPKG_DEVS_ETH_GRETH_FLUSH
                           eth_dsr,            // Custom DSR which invalidates DCACHE 
#else
			   eth_drv_dsr,         // Kernel DSR
#endif
                           &gi->interrupt_handle, // handle to intr obj
                           &gi->interrupt_object ); // space for int obj
  cyg_drv_interrupt_attach(gi->interrupt_handle);
  cyg_drv_interrupt_acknowledge(gi->irq); 
  cyg_drv_interrupt_unmask(gi->irq);
    
  // Enable device
  gi->active = 1;

  /* Enable receiver and transmiter and interrupts  */
  REGORIN(gi->regs->control , GRETH_RXEN | GRETH_TXEN | GRETH_TXI | GRETH_RXI);
}


static void greth_stop( struct eth_drv_sc *sc ) {
  
  greth_info *gi = (greth_info *) sc->driver_private;
  struct bd_info *bdi = (struct bd_info *) &(gi->bdi);
  int i;
  
  db_printf("greth_stop\n");
   
  /* Free interrupt hadler  */
  cyg_interrupt_delete(gi->interrupt_handle);
  
  /* Disable receiver and transmitesr */
  REGANDIN(gi->regs->control , ~(GRETH_RXEN | GRETH_TXEN | GRETH_TXI | GRETH_RXI));

  for (i = 0; i < GRETH_RXBD_NUM; i++) {
    SAVE(bdi->rx_ring[i].stat, 0);
  }
  
  for (i = 0; i < GRETH_TXBD_NUM; i++) {
    SAVE(bdi->tx_ring[i].stat, 0);
  }
  
  memset(bdi->tx_keys, 0, sizeof(bdi->tx_keys));
      
  gi->active = 0;    

}

static cyg_uint32 eth_isr(cyg_vector_t vector, cyg_addrword_t data) {
  struct eth_drv_sc *sc = (struct eth_drv_sc *)data;
  greth_info *gi = (greth_info *)sc->driver_private;

  cyg_uint32 int_events, calldsr = 0;

  cyg_drv_interrupt_acknowledge(gi->irq);
  
  cyg_drv_interrupt_mask(gi->irq);

  
  /* schedule dsr */
  return (CYG_ISR_HANDLED|CYG_ISR_CALL_DSR);        
}

/* This dsr is only used if CYGPKG_DEVS_ETH_GRETH_FLUSH is defined */
static void eth_dsr(cyg_vector_t vector, cyg_ucount32 count, cyg_addrword_t data) {
  struct eth_drv_sc *sc = (struct eth_drv_sc *)data;
  HAL_DCACHE_INVALIDATE_ALL();
  eth_drv_dsr( vector, count, (cyg_addrword_t)sc );
}

#ifdef CYGPKG_DEVS_ETH_GRETH_GBIT
static void greth_deliverGBIT(greth_info *gi, struct eth_drv_sc *sc) {
   volatile greth_bd *bdp;
   struct ifnet *ifp = &sc->sc_arpcom.ac_if;
   struct mbuf *m;
   struct ether_header *eh;

  cyg_uint32 status, pkt_len;

 /* Handle received packets */
  while (1) {
    
    bdp = gi->bdi.rx_ring + gi->bdi.rx_cur;
    
    LOAD(bdp->stat, status);
    
    if ((status & GRETH_BD_EN) == 0) { /* packet received */

    if (status & GRETH_RXBD_STATUS) {
      if (status & GRETH_RXBD_ERR_AE) {
        diag_printf("GRETH(%d): Rx alignment error.\n", gi->idx);
      }
      if (status & GRETH_RXBD_ERR_FT) {
        diag_printf("GRETH(%d): Rx frame to long error.\n", gi->idx);
      }
      if (status & GRETH_RXBD_ERR_CRC) {
        diag_printf("GRETH(%d): Rx crc error.\n", gi->idx);
      }
      if (status & GRETH_RXBD_ERR_OE) {
        diag_printf("GRETH(%d): Rx fifo overrun error.\n", gi->idx);
      }

      /* enable descriptor for new packet */
      REGORIN(bdp->stat, GRETH_BD_EN | GRETH_BD_IE | ((gi->bdi.rx_cur == GRETH_RXBD_NUM_MASK) ? GRETH_BD_WR : 0) );
      REGORIN(gi->regs->control, GRETH_RXEN);
      
      gi->bdi.rx_cur = ((gi->bdi.rx_cur + 1) & GRETH_RXBD_NUM_MASK);
      
      /* bump error stats */
      ifp->if_ierrors++;
      
      continue;
    }

    pkt_len = status & GRETH_BD_LEN;
    
    /* Get a MBuf to put cluster into */
    m = gi->bdi.rxmbufs[gi->bdi.rx_cur];

    m->m_pkthdr.rcvif = ifp;
        
    m->m_len = m->m_pkthdr.len = 
      pkt_len - sizeof(struct ether_header);
    
    eh = (struct ether_header *)(mtod(m,unsigned int));
    m->m_data += sizeof(struct ether_header);
    
		/* IPv4 checksum */
		if ( status & GRETH_RXBD_IP_DEC ){
			m->m_pkthdr.csum_flags |= CSUM_IP_CHECKED;
			if ( !(status & GRETH_RXBD_IP_CSERR) ){
				/* An IPv4 Checksum OK detected */
				m->m_pkthdr.csum_flags |= CSUM_IP_VALID;
			}
		}
		
		/* UDP or TCP checksum Check */
		if ( ((status & GRETH_RXBD_UDP_DEC) && !(status & GRETH_RXBD_UDP_CSERR)) ||
		     ((status & GRETH_RXBD_TCP_DEC) && !(status & GRETH_RXBD_TCP_CSERR)) ){
				/* An UDP or TCP Checksum OK detected */
				m->m_pkthdr.csum_flags |= CSUM_DATA_VALID|CSUM_PSEUDO_HDR;
				m->m_pkthdr.csum_data = 0xFFFF;
		}
    
    /* Push MBuf onto IP stack */
    ether_input(ifp, eh, m);
    
    /* Bump stats */
    ifp->if_ipackets++;
    
    m=NULL;
    
    /* Aloocate new mbuf for incoming packets */   
    MGETHDR(m,M_WAIT, MT_DATA);
    if ( !m ){
      diag_printf("GRETH(%d): Rx out of MBUF(s)\n", gi->idx);
      /* skip packet */
    }
    MCLGET(m, M_WAIT);
    m->m_data += ALIGN_IPHDR;
    
    gi->bdi.rxmbufs[gi->bdi.rx_cur] = m;
    SAVE(bdp->addr,mtod(m,unsigned int));
    
    /* clear descriptor */
    SAVE(bdp->stat, 0);

    /* enable descriptor for new packet */
    SAVE(bdp->stat, 
      GRETH_BD_EN | 
      GRETH_BD_IE | 
      ((gi->bdi.rx_cur == GRETH_RXBD_NUM_MASK) ? GRETH_BD_WR : 0) 
      );
    /* Tell MAC about new packet available */
    REGORIN(gi->regs->control, GRETH_RXEN);
    
    gi->bdi.rx_cur = ((gi->bdi.rx_cur + 1) & GRETH_RXBD_NUM_MASK);
    }
    else break;

  }
  
}
#endif

#ifndef CYGPKG_DEVS_ETH_GRETH_GBIT_ONLY
static void greth_deliver100(greth_info *gi, struct eth_drv_sc *sc)
{
  volatile greth_bd *bdp;
  cyg_uint32 status, pkt_len;
  
 /* Handle received packets */
  while (1) {
    
    bdp = gi->bdi.rx_ring + gi->bdi.rx_cur;
    
    LOAD(bdp->stat, status);
    
    if ((status & GRETH_BD_EN) == 0) { /* packet received */

      if (status & GRETH_RXBD_STATUS) {
	if (status & GRETH_RXBD_ERR_AE) {
	  diag_printf("GRETH(%d): Rx alignment error.\n", gi->idx);
	}
	if (status & GRETH_RXBD_ERR_FT) {
	  diag_printf("GRETH(%d): Rx frame to long error.\n", gi->idx);
	}
	if (status & GRETH_RXBD_ERR_CRC) {
	  diag_printf("GRETH(%d): Rx crc error.\n", gi->idx);
	}
	if (status & GRETH_RXBD_ERR_OE) {
	  diag_printf("GRETH(%d): Rx fifo overrun error.\n", gi->idx);
	}

	/* enable descriptor for new packet */
	REGORIN(bdp->stat, GRETH_BD_EN | GRETH_BD_IE | ((gi->bdi.rx_cur == GRETH_RXBD_NUM_MASK) ? GRETH_BD_WR : 0) );
	REGORIN(gi->regs->control, GRETH_RXEN);
      
	gi->bdi.rx_cur = ((gi->bdi.rx_cur + 1) & GRETH_RXBD_NUM_MASK);
	continue;

      }

      pkt_len = status & GRETH_BD_LEN;
    
      /*  notify stack */
      (sc->funs->eth_drv->recv)( sc, pkt_len );
      
      /* clear descriptor */
      SAVE(bdp->stat, 0);

      /* enable descriptor for new packet */
      REGORIN(bdp->stat, GRETH_BD_EN | GRETH_BD_IE | ((gi->bdi.rx_cur == GRETH_RXBD_NUM_MASK) ? GRETH_BD_WR : 0) );
      REGORIN(gi->regs->control, GRETH_RXEN);
      
      gi->bdi.rx_cur = ((gi->bdi.rx_cur + 1) & GRETH_RXBD_NUM_MASK);
    }
    else break;

  }
  
}
#endif

static void greth_deliver(struct eth_drv_sc *sc) {
  greth_info *gi = (greth_info *)sc->driver_private;
  volatile greth_bd *bdp;

  cyg_uint32 status;
#ifdef CYGPKG_DEVS_ETH_GRETH_GBIT
  if ( gi->gbit ){
    greth_deliverGBIT(gi,sc);
  }
#endif
#if defined(CYGPKG_DEVS_ETH_GRETH_GBIT) && !defined(CYGPKG_DEVS_ETH_GRETH_GBIT_ONLY)
  else
#endif
#ifndef CYGPKG_DEVS_ETH_GRETH_GBIT_ONLY
  {
    greth_deliver100(gi,sc);
  }
#endif
  
  /* handle sent packets */
  while (gi->bdi.tx_free != GRETH_TXBD_NUM) {
    
    bdp = gi->bdi.tx_ring + gi->bdi.tx_last;
    
    LOAD(bdp->stat, status);
    
    if (status & GRETH_BD_EN) break; /* packet not sent */
    
#ifdef CYGPKG_DEVS_ETH_GRETH_GBIT
    if ( !(gi->gbit && (status & GRETH_TXBD_MORE)) )
#endif
    {
      if (status & GRETH_TXBD_STATUS) {
        (sc->funs->eth_drv->tx_done)( sc, gi->bdi.tx_keys[gi->bdi.tx_last], 1 ); /*indicate error */

        if (status & GRETH_TXBD_ERR_UE) {
          diag_printf("GRETH(%d): Tx fifo underrun error.\n", gi->idx);
        }
      
        if (status & GRETH_TXBD_ERR_AL) {
          diag_printf("GRETH(%d): Tx attempt limit error.\n", gi->idx);
        }

        if (status & GRETH_TXBD_ERR_LC) {
          diag_printf("GRETH(%d): Tx Late Collision.\n", gi->idx);
        }
                
      } else {
        (sc->funs->eth_drv->tx_done)( sc, gi->bdi.tx_keys[gi->bdi.tx_last], 0 );
      }
      
    }
    
    gi->bdi.tx_last = ((gi->bdi.tx_last + 1) & GRETH_TXBD_NUM_MASK);
    gi->bdi.tx_free++;
  }

  cyg_drv_interrupt_unmask(gi->irq);
  
}


/* /\* Notifies stack about received packets *\/ */
/* static void greth_rx(struct eth_drv_sc *sc) { */

/*   greth_info *gi = (greth_info *)sc->driver_private; */
/*   volatile greth_bd *bdp; */

/*   cyg_uint32 status; */
/*   int	pkt_len; */

/*   /\* Handle received packets *\/ */
/*   while (1) { */

/*     bdp = gi->bdi.rx_ring + gi->bdi.rx_cur; */

/*     LOAD(bdp->stat, status); */
    
/*     if ((status & GRETH_BD_EN) == 0) { /\* packet received *\/ */

/*       if (status & GRETH_RXBD_STATUS) { */
/* 	if (status & GRETH_RXBD_ERR_AE) { */
/* 	  diag_printf("GRETH(%d): Rx alignment error.\n", gi->idx); */
/* 	  continue; */
/* 	} */
/* 	if (status & GRETH_RXBD_ERR_FT) { */
/* 	  diag_printf("GRETH(%d): Rx frame to long error.\n", gi->idx); */
/* 	  continue; */
/* 	} */
/* 	if (status & GRETH_RXBD_ERR_CRC) { */
/* 	  diag_printf("GRETH(%d): Rx crc error.\n", gi->idx); */
/* 	  continue; */
/* 	} */
/* 	if (status & GRETH_RXBD_ERR_OE) { */
/* 	  diag_printf("GRETH(%d): Rx fifo overrun error.\n", gi->idx); */
/* 	  continue; */
/* 	} */
/*       } */

/*       pkt_len = status & GRETH_BD_LEN; */

/*       /\*  notify stack *\/ */
/*       (sc->funs->eth_drv->recv)( sc, pkt_len ); */
      
/*       /\* clear descriptor *\/ */
/*       SAVE(bdp->stat, 0); */

/*       /\* enable descriptor for new packet *\/ */
/*       REGORIN(bdp->stat, GRETH_BD_EN | GRETH_BD_IE | ((gi->bdi.rx_cur == GRETH_RXBD_NUM_MASK) ? GRETH_BD_WR : 0) ); */
/*       REGORIN(gi->regs->control, GRETH_RXEN); */
      
/*       gi->bdi.rx_cur = ((gi->bdi.rx_cur + 1) & GRETH_RXBD_NUM_MASK); */
/*     } */
/*     else break; */

/*   } */
/* } */


/* /\* Checks for sent packets and passes tx-keys up the stack when packets are transmitted, called from can_send() and deliver() *\/ */
/* static void greth_tx(struct eth_drv_sc *sc) { */
/*   greth_info *gi = (greth_info *)sc->driver_private; */
/*   volatile greth_bd *bdp; */
/*   cyg_uint32 status; */

/*   while (gi->bdi.tx_free != GRETH_TXBD_NUM) { */

/*     bdp = gi->bdi.tx_ring + gi->bdi.tx_last; */
    
/*     LOAD(bdp->stat, status); */
    
/*     if (status & GRETH_BD_EN) break; /\* packet not sent *\/ */

/*     if (status & GRETH_TXBD_STATUS) { */
/*       (sc->funs->eth_drv->tx_done)( sc, gi->bdi.tx_keys[gi->bdi.tx_last], 1 ); /\*indicate error *\/ */
/*       diag_printf("Error in transfer.\n"); */
/*     } */
/*     else { */
/*       (sc->funs->eth_drv->tx_done)( sc, gi->bdi.tx_keys[gi->bdi.tx_last], 0 ); */
/*       //      db_printf("Descriptor %d sent successfully\n", bdi->tx_last); */
/*     } */

/*     gi->bdi.tx_last = ((gi->bdi.tx_last + 1) & GRETH_TXBD_NUM_MASK); */
/*     gi->bdi.tx_free++; */
/*   } */
/* } */


static int greth_can_send(struct eth_drv_sc *sc) {
  greth_info *gi = (greth_info *)sc->driver_private;

  db_printf("can_send - tx_free: %d\n", gi->bdi.tx_free);

  return gi->bdi.tx_free;
}

static void greth_send(struct eth_drv_sc *sc,
                         struct eth_drv_sg *sg_list, int sg_len, int total_len,
                         unsigned long key) {

  greth_info *gi = (greth_info *)sc->driver_private;
  struct bd_info *bdi = (struct bd_info *)&(gi->bdi);
  
  cyg_uint32 status, addr;
  int len, i;
  cyg_uint8 *to_addr;
  char *buf;

  db_printf("greth_send(): tx_next: %d, sg_len: %d, tx_free: %d\n", bdi->tx_next,sg_len,bdi->tx_free);
  
  if ( gi->gbit ) {
    if ( bdi->tx_free < sg_len ){
      diag_printf("greth_send called but not enough free descriptors!\n");
      return;
    }
  }else if (bdi->tx_free == 0) 
  {
    diag_printf("greth_send called but no free descriptors!\n");
    return;
  }

  if (total_len > GRETH_TX_BUF_SIZE) {
    diag_printf("greth: tx frame too long!.\n");
    return;
  }

  if ( gi->gbit ) {
    /* GBit MAC: Use scatter gather and Hardware Checksum Calculation */
    for ( i=0; i<sg_len; i++){
      len = sg_list[i].len;
      buf = sg_list[i].buf;
      
      SAVE(bdi->tx_ring[bdi->tx_next].addr,buf);
      
      SAVE(bdi->tx_ring[bdi->tx_next].stat,
        GRETH_BD_IE | 
        GRETH_BD_EN |
        (len & GRETH_BD_LEN) | 
        ((bdi->tx_next == GRETH_TXBD_NUM_MASK) ? GRETH_BD_WR : 0) |
        ((i+1)==sg_len ? 0 : GRETH_TXBD_MORE) |
        GRETH_TXBD_IPCS |
        GRETH_TXBD_TCPCS |
        GRETH_TXBD_UDPCS
       );
      
      if ( i+1 == sg_len ) {
        bdi->tx_keys[bdi->tx_next] = key;    
      }else{
        bdi->tx_keys[bdi->tx_next] = 0;
      }
      bdi->tx_next = (bdi->tx_next + 1) & GRETH_TXBD_NUM_MASK;
    }
    bdi->tx_free-=sg_len;

  }else
  {

    /* Fill in a Tx key */
    bdi->tx_keys[bdi->tx_next] = key;
  
    LOAD(bdi->tx_ring[bdi->tx_next].addr, addr);
    to_addr = (cyg_uint8 *) addr;
  
    for (i = 0;  i < sg_len;  i++) {
      len = sg_list[i].len;
      memcpy(to_addr, (void*)sg_list[i].buf, len); 
      to_addr += len; 
    }
  
#if DEBUG_TX_PACKETS
    diag_printf("TX\n");
    greth_print_packet((unsigned long)addr, total_len);
#endif

    /* 10/100 MAC */
    SAVE(bdi->tx_ring[bdi->tx_next].stat, 
      GRETH_BD_IE | 
      (total_len & GRETH_BD_LEN) | 
      ((bdi->tx_next == GRETH_TXBD_NUM_MASK) ? GRETH_BD_WR : 0)
       );
  
    REGORIN(bdi->tx_ring[bdi->tx_next].stat, GRETH_BD_EN);                /* set enable */
    
    bdi->tx_next = (bdi->tx_next + 1) & GRETH_TXBD_NUM_MASK;
    bdi->tx_free--;
  }
  
  REGORIN(gi->regs->control, GRETH_TXEN);                               /* enable transmitter */

  return;
}

static void greth_recv( struct eth_drv_sc *sc, struct eth_drv_sg *sg_list, int sg_len ) {
  greth_info *gi = (greth_info *)sc->driver_private;
  struct bd_info *bdi = (struct bd_info *) &(gi->bdi);

  cyg_uint8 *from_addr;
  cyg_uint32 from, status, i;
  int	pkt_len;

  db_printf ("greth_recv() - rx_cur: %d\n", bdi->rx_cur);

  LOAD(bdi->rx_ring[bdi->rx_cur].stat, status);
  pkt_len = status & GRETH_BD_LEN;

  LOAD(bdi->rx_ring[bdi->rx_cur].addr, from);
  from_addr = (cyg_uint8 *) from;

#if DEBUG_RX_PACKETS
  greth_print_packet((unsigned long)from, pkt_len);
#endif
    
  for ( i = 0; i < sg_len; i++ ) {
    cyg_uint8 *to_addr;
    int len;
    to_addr = (cyg_uint8 *)(sg_list[i].buf);
    len = sg_list[i].len;

    if (to_addr == 0 || len <= 0)
      return; // out of mbufs
    
    if ( len > pkt_len )
      len = pkt_len;
    
    memcpy( to_addr, (void *)from_addr, len );
    from_addr += len;
    pkt_len -= len;
    
  }

  if (pkt_len > 0) {
    diag_printf("GRETH(%d): Receive sg_list to small.\n", gi->idx);
  }
}

static void greth_poll(struct eth_drv_sc *sc) {
  greth_info *gi = (greth_info *)sc->driver_private;

  eth_isr(gi->irq, (cyg_addrword_t) sc);
  greth_deliver(sc);
}

static int greth_int_vector(struct eth_drv_sc *sc) {
  greth_info *gi = (greth_info *)sc->driver_private;
  return gi->irq;
}

static int greth_control(struct eth_drv_sc *sc, unsigned long key, void *data, int data_length) {

  switch ( key ) {
#ifdef ETH_DRV_SET_MAC_ADDRESS
  case ETH_DRV_SET_MAC_ADDRESS:
    if ( 6 != data_length )
      return -2;
    return eth_set_mac_address( sc, data );
#endif
#ifdef ETH_DRV_GET_MAC_ADDRESS
  case ETH_DRV_GET_MAC_ADDRESS:
    return eth_get_mac_address( sc, data );
#endif

#ifdef ETH_DRV_SET_MC_LIST
  case ETH_DRV_SET_MC_LIST:
    /* Get rid of warnings about no multicast support .. doesn't do anything.
     */
    return 0;
#endif 

  default:
    break;
  }
  return -1;
}

