//___________________________________________
#define _str_HAL_SMP_CPU_MAX(x) #x
#define smp_cyg_test_argc 5
char *_cyg_argv[] = {
  "radix.exe",
  "-p",
  "2", /* not used, using HAL_SMP_CPU_MAX */
  "-m", 
  "10"
};
#define smp_cyg_test_argv &_cyg_argv
//'''''''''''''''''''''''''''''''''''''''''''
