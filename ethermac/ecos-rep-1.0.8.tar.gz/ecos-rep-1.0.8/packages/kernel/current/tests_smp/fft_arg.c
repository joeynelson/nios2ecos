
//___________________________________________
#define smp_cyg_test_argc 11
char *_cyg_argv[] = {
  "fft.exe",
  "-s",
  "-t",
  "-l",
  "5",
  "-n",
  "256",
  "-p",
  "2", /* not used, using HAL_SMP_CPU_MAX */
  "-m", 
  "16"
};
#define smp_cyg_test_argv &_cyg_argv
//'''''''''''''''''''''''''''''''''''''''''''
