#ifndef __LINUX_COMPLETION_H__
#define __LINUX_COMPLETION_H__

struct completion { } ;

#endif /* __LINUX_COMPLETION_H__ */

