#ifndef __LINUX_TIMER_H__
#define __LINUX_TIMER_H__

/* Not yet */

struct timer_list { } ;


#endif /* __LINUX_TIMER_H__ */

