
#define USE_SSL

#include <stdio.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#ifdef USE_SSL
#include <openssl/ssl.h>
#endif

#define ADDRESS  "127.0.0.1"
#define PORT     3999

#ifdef USE_SSL
#define WRITE(a,b,c) SSL_write(a,b,c)
#define READ(a,b,c)  SSL_read(a,b,c)
#else
#define WRITE(a,b,c) write(a,b,c)
#define READ(a,b,c)  read(a,b,c)
#endif

void pexit(char *str)
{
  printf("%s\n",str);
  exit(-1);
}

int create_tcpip_socket_and_wait(int *sock, unsigned short port)
{  
  struct sockaddr_in addr,from;
  int s,s2;
  int one=1;
  socklen_t len = sizeof(struct sockaddr_in);
  
  s = socket(AF_INET, SOCK_STREAM, 0);
  if ( s < 0 ){
    perror("socket()");
    return -1;
  }
  
  if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one))) {
    close(s);
    perror("setsockopt()");
    return -2;
  }
  
  memset(&addr,0,len);
  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);
  addr.sin_addr.s_addr = INADDR_ANY;
  
  if ( bind(s,(struct sockaddr *)&addr,len) ){
    close(s);
    perror("bind()");
    return -3;
  }
  
  if ( listen(s,3) ){
    close(s);
    perror("listen()");
    return -4;
  }
  
  memset(&from,0,len);
  if ( (s2=accept(s,(struct sockaddr *)&from,&len)) < 0){
    close(s);
    perror("accept()");
    return -5;
  }
  
  if ( sock )
    *sock = s2;
  return 0;
}

#ifdef USE_SSL
int sslc_pem_passwd_cb(char *buf, int size, int rwflag, void *userdata)
{
  int len;
  printf("In Password Callback (%s)\n",userdata);
  if ( !userdata )
    return 0;
  
  /* Password must fit into buffer */
  len = strlen(userdata);
  if ( size < len+1 )
    return 0;
  
  /* Copy password to buffer */
  strcpy(buf,userdata);
  return len;
}
#endif

struct user_db_entry {
  char *user;
  char *pass;
};

struct user_db_entry user_db[] = 
{
  {"daniel","gaisler"},
  {"jiri","jiri"},
  {0,0}
};

struct user_db_entry *get_user(char *username)
{
  struct user_db_entry *curr;
  
  if ( !username )
    return NULL;
    
  curr = &user_db[0];
  while( curr->user ){
    if ( !strcmp(username,curr->user) ){
      return curr;
    }
    curr++;
  }
  return NULL;
}

int validate_pass(struct user_db_entry *user, char *pass)
{
  if ( pass && user->pass && !strcmp(user->pass,pass) ){
    return 1;
  }
  return 0;
}

#ifdef USE_SSL
int protocol(SSL *ssl)
#else
/* ssl = socket fd */
int protocol(int ssl)
#endif
{
  int len;
  char buf[128];
  struct user_db_entry *user;
  
  /* Wait for USER command */
  len = READ(ssl,buf,128);
  if ( len < 6 ){
    return -1;
  }
  
  if ( buf[0] != 'U' ||
       buf[1] != 'S' ||
       buf[2] != 'E' ||
       buf[3] != 'R' ||
       buf[4] != ' ' || 
       buf[len-1] != '\n'
       ){
    return -1;
  }
  
  /* Lookup user */
  buf[len-1] = '\0';
  user = get_user(&buf[5]);
  if ( !user ){
    printf("Failed to find user\n");
    WRITE(ssl,"NO\n",3);
    return -1;
  }
  
  /* Send proceed */
  WRITE(ssl,"OK\n",3);
  
  /* Wait for PASS command */
  len = READ(ssl,buf,128);
  if ( len < 6 ){
    return -1;
  }
  
  if ( buf[0] != 'P' ||
       buf[1] != 'A' ||
       buf[2] != 'S' ||
       buf[3] != 'S' ||
       buf[4] != ' ' || 
       buf[len-1] != '\n'
       ){
    return -1;
  }
  /* Validate password */
  buf[len-1] = '\0';
  if ( !validate_pass(user,&buf[5]) ){
    printf("Password incorrect\n");
    WRITE(ssl,"NO\n",3);
    return -1;
  }
  
  printf("User %s has logged in\n",user->user);
  
  /* Send proceed */
  WRITE(ssl,"OK\n",3);
  
  while(1){
    /* do protocol, Handle user */
    sleep(1);
  }
  return 0;
}

int main(void)
{
  int ret;
  int sock;

#ifdef USE_SSL
  SSL *ssl;
  SSL_CTX *ctx;
  SSL_METHOD *method;
  
  SSL_load_error_strings();
  ret = SSL_library_init();
  if ( ret != 1 ){
    pexit("SSL_library_init()");
  }
  
  /* use SSLv3 method framework */
  method = SSLv3_method();
  
  /* New SSL Context */
  ctx = SSL_CTX_new(method);
  if ( !ctx )
    pexit("SSL_CTX_new()");
  
  ret = SSL_CTX_use_certificate_file(ctx,"server_cacert.pem",SSL_FILETYPE_PEM);
  if ( ret != 1 ){
    pexit("SSL_CTX_use_certificate_file failed");
  }
  
  /* Set password callback */
  SSL_CTX_set_default_passwd_cb(ctx,sslc_pem_passwd_cb);
  
  /* The password will popup as userdata in password callback function */
  SSL_CTX_set_default_passwd_cb_userdata(ctx,"Hejhej");
  
  ret = SSL_CTX_use_PrivateKey_file(ctx,"server_pkey.pem",SSL_FILETYPE_PEM);
  if ( ret != 1 ){
    pexit("SSL_CTX_use_PrivateKey_file");
  }
#endif

  printf("Waiting for a incomming TCP/IP connection\n");
  
  if ( create_tcpip_socket_and_wait(&sock,PORT) ){
    pexit("do_tcpip_socket_and_connect()");
  }
  
  printf("TCP/IP Connection made\n");

#ifdef USE_SSL  
  /* Create SSL handle */
  ssl = SSL_new(ctx);
  if ( !ssl ){
    pexit("SSL_new");
  }

  /* Connect SSL layer with socket */
  if ( SSL_set_fd(ssl,sock) != 1 ){
    pexit("SSL_set_fd");
  }

  /* Wait for client to handshake with server */
  ret = SSL_accept(ssl);
  if ( ret == 0 ){
    pexit("SSL_accept failed with 0");
  }else if ( ret < 0 ){
    pexit("SSL_accept failed with <0");
  }
  
  printf("SSL server connection is up\n\n\n");
  protocol(ssl);
  SSL_CTX_free(ctx);
#else
  printf("Server connection is up\n\n\n");
  protocol(sock);
#endif
  
  close(sock);
  return 0;
}
