
#define USE_SSL

#include <stdio.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

#include <string.h>
#include <dirent.h>

#ifdef USE_SSL
#include <openssl/ssl.h>
#endif

#define ADDRESS  "127.0.0.1"
#define PORT     3999

#ifdef USE_SSL
#define WRITE(a,b,c) SSL_write(a,b,c)
#define READ(a,b,c)  SSL_read(a,b,c)
#else
#define WRITE(a,b,c) write(a,b,c)
#define READ(a,b,c)  read(a,b,c)
#endif

#define STACK_SIZE (CYGNUM_HAL_STACK_SIZE_TYPICAL + 0x1000)
static char stack[STACK_SIZE];
static cyg_thread thread_data;
static cyg_handle_t thread_handle;

void listdir( char *name, int statp );

void pexit(char *str)
{
  printf("%s\n",str);
  exit(-1);
}

int create_tcpip_socket_and_wait(int *sock, unsigned short port)
{  
  struct sockaddr_in addr,from;
  int s,s2;
  int one=1;
  socklen_t len = sizeof(struct sockaddr_in);
  int ret;
  
  s = socket(AF_INET, SOCK_STREAM, 0);
  if ( s < 0 ){
    perror("socket()");
    return -1;
  }
#if 0  
  if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one))) {
    close(s);
    perror("setsockopt()");
    return -2;
  }
#endif
  memset(&addr,0,len);
  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);
  addr.sin_addr.s_addr = INADDR_ANY;
  
  if ( (ret=bind(s,(struct sockaddr *)&addr,len)) ){
    printf("bind(): %d, %d\n",ret,errno);
    close(s);
    perror("bind()");
    return -3;
  }
  
  if ( listen(s,3) ){
    close(s);
    perror("listen()");
    return -4;
  }
  
  memset(&from,0,len);
  if ( (s2=accept(s,(struct sockaddr *)&from,&len)) < 0){
    close(s);
    perror("accept()");
    return -5;
  }
  
  if ( sock )
    *sock = s2;
  return 0;
}

#ifdef USE_SSL
int sslc_pem_passwd_cb(char *buf, int size, int rwflag, void *userdata)
{
  int len;
  printf("In Password Callback (%s)\n",userdata);
  if ( !userdata )
    return 0;
  
  /* Password must fit into buffer */
  len = strlen(userdata);
  if ( size < len+1 )
    return 0;
  
  /* Copy password to buffer */
  strcpy(buf,userdata);
  return len;
}
#endif

struct user_db_entry {
  char *user;
  char *pass;
};

struct user_db_entry user_db[] = 
{
  {"daniel","gaisler"},
  {"jiri","jiri"},
  {0,0}
};

struct user_db_entry *get_user(char *username)
{
  struct user_db_entry *curr;
  
  if ( !username )
    return NULL;
    
  curr = &user_db[0];
  while( curr->user ){
    if ( !strcmp(username,curr->user) ){
      return curr;
    }
    curr++;
  }
  return NULL;
}

int validate_pass(struct user_db_entry *user, char *pass)
{
  if ( pass && user->pass && !strcmp(user->pass,pass) ){
    return 1;
  }
  return 0;
}

#ifdef USE_SSL
int protocol(SSL *ssl)
#else
/* ssl = socket fd */
int protocol(int ssl)
#endif
{
  int len;
  char buf[128];
  struct user_db_entry *user;
  
  /* Wait for USER command */
  len = READ(ssl,buf,128);
  if ( len < 6 ){
    return -1;
  }
  
  if ( buf[0] != 'U' ||
       buf[1] != 'S' ||
       buf[2] != 'E' ||
       buf[3] != 'R' ||
       buf[4] != ' ' || 
       buf[len-1] != '\n'
       ){
    return -1;
  }
  
  /* Lookup user */
  buf[len-1] = '\0';
  user = get_user(&buf[5]);
  if ( !user ){
    printf("Failed to find user\n");
    WRITE(ssl,"NO\n",3);
    return -1;
  }
  
  /* Send proceed */
  WRITE(ssl,"OK\n",3);
  
  /* Wait for PASS command */
  len = READ(ssl,buf,128);
  if ( len < 6 ){
    return -1;
  }
  
  if ( buf[0] != 'P' ||
       buf[1] != 'A' ||
       buf[2] != 'S' ||
       buf[3] != 'S' ||
       buf[4] != ' ' || 
       buf[len-1] != '\n'
       ){
    return -1;
  }
  /* Validate password */
  buf[len-1] = '\0';
  if ( !validate_pass(user,&buf[5]) ){
    printf("Password incorrect\n");
    WRITE(ssl,"NO\n",3);
    return -1;
  }
  
  printf("User %s has logged in\n",user->user);
  
  /* Send proceed */
  WRITE(ssl,"OK\n",3);
  
  while(1){
    /* do protocol, Handle user */
    sleep(1);
  }
  return 0;
}

void
ssl_server(cyg_addrword_t arg_unused)
{
  int ret;
  int sock;

#ifdef USE_SSL
  SSL *ssl;
  SSL_CTX *ctx;
  SSL_METHOD *method;
   
  listdir( "/usr/ssl", true );
  
  SSL_load_error_strings();
  ret = SSL_library_init();
  if ( ret != 1 ){
    pexit("SSL_library_init()");
  }
  
  /* use SSLv3 method framework */
  method = SSLv3_method();
  
  /* New SSL Context */
  ctx = SSL_CTX_new(method);
  if ( !ctx )
    pexit("SSL_CTX_new()");
  
  ret = SSL_CTX_use_certificate_file(ctx,"/usr/ssl/server_cacert.pem",SSL_FILETYPE_PEM);
  if ( ret != 1 ){
    pexit("SSL_CTX_use_certificate_file failed");
  }
  
  /* Set password callback */
  SSL_CTX_set_default_passwd_cb(ctx,sslc_pem_passwd_cb);
  
  /* The password will popup as userdata in password callback function */
  SSL_CTX_set_default_passwd_cb_userdata(ctx,"Hejhej");
  
  ret = SSL_CTX_use_PrivateKey_file(ctx,"/usr/ssl/server_pkey.pem",SSL_FILETYPE_PEM);
  if ( ret != 1 ){
    pexit("SSL_CTX_use_PrivateKey_file");
  }
#endif

  printf("Waiting for a incomming TCP/IP connection\n");
  
  if ( create_tcpip_socket_and_wait(&sock,PORT) ){
    pexit("do_tcpip_socket_and_connect()");
  }
  
  printf("TCP/IP Connection made\n");

#ifdef USE_SSL  
  /* Create SSL handle */
  ssl = SSL_new(ctx);
  if ( !ssl ){
    pexit("SSL_new");
  }

  /* Connect SSL layer with socket */
  if ( SSL_set_fd(ssl,sock) != 1 ){
    pexit("SSL_set_fd");
  }

  /* Wait for client to handshake with server */
  ret = SSL_accept(ssl);
  if ( ret == 0 ){
    printf("SSL error: %d\n",SSL_get_error(ssl,ret));
    pexit("SSL_accept failed with 0");
  }else if ( ret < 0 ){
    printf("SSL error: %d\n",SSL_get_error(ssl,ret));
    pexit("SSL_accept failed with <0");
  }
  
  printf("SSL server connection is up\n\n\n");
  protocol(ssl);
  SSL_CTX_free(ctx);
#else
  printf("Server connection is up\n\n\n");
  protocol(sock);
#endif
  
  close(sock);
}

void
cyg_start(void)
{
    init_all_network_interfaces();

    // Create a main thread, so we can run the scheduler and have time 'pass'
    cyg_thread_create(10,                // Priority - just a number
                      ssl_server,          // entry
                      0,                 // entry parameter
                      "httpd test",    // Name
                      &stack[0],         // Stack
                      STACK_SIZE,        // Size
                      &thread_handle,    // Handle
                      &thread_data       // Thread data structure
            );
    cyg_thread_resume(thread_handle);  // Start it
    cyg_scheduler_start();
}

//==========================================================================
// Taken from romfs example.

#include <pkgconf/fs_rom.h>
#include <cyg/fileio/fileio.h>

//==========================================================================

#ifdef ROM_IN_FLASH
MTAB_ENTRY( rom_mte,
                   "/",
                   "romfs",
                   "",
                   (CYG_ADDRWORD) FS_ADDR );
#else

/* Include the filesystem */
#include "romfs_root.img.h"

MTAB_ENTRY( rom_mte,
                   "/",
                   "romfs",
                   "",
                   (CYG_ADDRWORD) &filedata[0] );
#endif
//==========================================================================

#ifndef CYGINT_ISO_STRING_STRFUNCS

char *strcat( char *s1, const char *s2 )
{
    char *s = s1;
    while( *s1 ) s1++;
    while( (*s1++ = *s2++) != 0);
    return s;
}

#endif

//==========================================================================

#define SHOW_RESULT( _fn, _res ) \
diag_printf("<FAIL>: " #_fn "() returned %d %s\n", _res, _res<0?strerror(errno):"");

#define CHKFAIL_TYPE( _fn, _res, _type ) { \
if ( _res != -1 ) \
    diag_printf("<FAIL>: " #_fn "() returned %d (expected -1)\n", _res); \
else if ( errno != _type ) \
    diag_printf("<FAIL>: " #_fn "() failed with errno %d (%s),\n    expected %d (%s)\n", errno, strerror(errno), _type, strerror(_type) ); \
}


void listdir( char *name, int statp )
{
    int err;
    DIR *dirp;
    
    diag_printf("<INFO>: reading directory %s\n",name);
    
    err = chdir( "/etc" );
    if ( err < 0 ) {
        SHOW_RESULT( chdir, err );
    }
    
    dirp = opendir( name );
    if( dirp == NULL ) SHOW_RESULT( opendir, -1 );

    for(;;)
    {
        struct dirent *entry = readdir( dirp );
        
        if( entry == NULL )
            break;

        diag_printf("<INFO>: entry %14s",entry->d_name);
        if( statp )
        {
            char fullname[PATH_MAX];
            struct stat sbuf;

            if( name[0] )
            {
                strcpy(fullname, name );
                if( !(name[0] == '/' && name[1] == 0 ) )
                    strcat(fullname, "/" );
            }
            else fullname[0] = 0;
            
            strcat(fullname, entry->d_name );
            
            err = stat( fullname, &sbuf );
            if( err < 0 )
            {
                if( errno == ENOSYS )
                    diag_printf(" <no status available>");
                else SHOW_RESULT( stat, err );
            }
            else
            {
                diag_printf(" [mode %08x ino %08x nlink %d size %d]",
                            sbuf.st_mode,sbuf.st_ino,sbuf.st_nlink,sbuf.st_size);
            }
        }

        diag_printf("\n");
    }

    err = closedir( dirp );
    if( err < 0 ) SHOW_RESULT( stat, err );
}
