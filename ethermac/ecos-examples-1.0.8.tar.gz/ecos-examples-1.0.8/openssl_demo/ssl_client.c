
#define USE_SSL

#include <stdio.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#ifdef USE_SSL
#include <openssl/ssl.h>
#endif

//#define ADDRESS  "127.0.0.1"
#define ADDRESS  "192.168.0.240"
#define PORT     3999

#ifdef USE_SSL
#define WRITE(a,b,c) SSL_write(a,b,c)
#define READ(a,b,c)  SSL_read(a,b,c)
#else
#define WRITE(a,b,c) write(a,b,c)
#define READ(a,b,c)  read(a,b,c)
#endif

void pexit(char *str)
{
  printf("%s\n",str);
  exit(-1);
}


int create_tcpip_socket_and_connect(int *sock, char *address, unsigned short port)
{  
  struct sockaddr_in addr;
  struct hostent *hp;
  int s;
  int one=1;
  socklen_t len = sizeof(struct sockaddr_in);
  
  s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if ( s < 0 ){
    perror("socket()");
    return -1;
  }
  
  hp = gethostbyname(address);
  if ( !hp ){
    perror("gethostbyname()");
    return -2;
  }

  memset(&addr,0,len);
  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);
  //addr.sin_addr.s_addr = inet_addr(address);
  addr.sin_addr = *(struct in_addr *)hp->h_addr_list[0];
  
  if ( connect(s,(struct sockaddr *)&addr,len) <0 ){
    perror("connect()");
    close(s);
    return -3;
  }
  
  if ( sock )
    *sock = s;
  return 0;
}

#ifdef USE_SSL
int sslc_pem_passwd_cb(char *buf, int size, int rwflag, void *userdata)
{
  int len;
  printf("In Password Callback (%s)\n",userdata);
  if ( !userdata )
    return 0;
  
  /* Password must fit into buffer */
  len = strlen(userdata);
  if ( size < len+1 )
    return 0;
  
  /* Copy password to buffer */
  strcpy(buf,userdata);
  return len;
}
#endif

#ifdef USE_SSL
int protocol(SSL *ssl, char *user, char *pass)
#else
/* ssl = socket fd */
int protocol(int ssl, char *user, char *pass)
#endif
{
  char buf[128];
  int len;
  
  printf("Trying to login as user %s\n",user);
  len = sprintf(buf,"USER %s\n",user);
  if ( WRITE(ssl,buf,len) != len ){
    pexit("SSL_write 1");
  }
  
  /* Get server response */
  if ( READ(ssl,buf,3) != 3 ){
    return -1;
  }
  
  if ( (buf[0] != 'O') || (buf[1]!='K') || (buf[2]!='\n') ){
    printf("Failed to login user\n");
    return -1;
  }
  
  /* Send password for daniel */
  printf("User %s OK, sending password\n",user);
  
  len = sprintf(buf,"PASS %s\n",pass);
  if ( WRITE(ssl,buf,len) != len ){
    return -1;
  }

  /* Get server response */
  if ( READ(ssl,buf,3) != 3 ){
    printf("Failed to login\n");
    return -1;
  }
  
  if ( (buf[0] != 'O') || (buf[1]!='K') || (buf[2]!='\n') ){
    printf("Failed to verify password for user\n");
    return -1;
  }
  
  printf("%s logged in\n",user);
  while(1){
    /* Do protocol */
    
    sleep(1);
  }
  
  return 0;
}

int main(void)
{
  int ret;
  int sock;
  
#ifdef USE_SSL
  SSL *ssl;
  SSL_CTX *ctx;
  SSL_METHOD *method;
   
  ret = SSL_library_init();
  SSL_load_error_strings();
  
  if ( ret != 1 ){
    pexit("SSL_library_init()");
  }
  

  /* use SSLv3 method framework */
  method = SSLv3_method();
  
  /* New SSL Context */
  ctx = SSL_CTX_new(method);
  if ( !ctx )
    pexit("SSL_CTX_new()");
  
  ret = SSL_CTX_use_certificate_file(ctx,"client_cacert.pem",SSL_FILETYPE_PEM);
  if ( ret != 1 ){
    pexit("SSL_CTX_use_certificate_file failed");
  }
  
  /* Set password callback */
  SSL_CTX_set_default_passwd_cb(ctx,sslc_pem_passwd_cb);

  /* The password will popup as userdata in password callback function */
  SSL_CTX_set_default_passwd_cb_userdata(ctx,"Dada");

  ret = SSL_CTX_use_RSAPrivateKey_file(ctx,"client_pkey.pem",SSL_FILETYPE_PEM);
  if ( ret != 1 ){
    pexit("SSL_CTX_use_RSAPrivateKey_file");
  }
#endif

  printf("Connecting server via TCP/IP\n");
  
  if ( create_tcpip_socket_and_connect(&sock,ADDRESS,PORT) ){
    printf("do_tcpip_socket_and_connect()\n");
    exit(-1);
  }
  
  printf("TCP/IP Connection made\n");
  sleep(1);

#ifdef USE_SSL  
  /* Create SSL handle */
  ssl = SSL_new(ctx);
  if ( !ssl ){
    pexit("SSL_new");
  }
  
  /* Connect SSL layer with socket */
  if ( SSL_set_fd(ssl,sock) != 1 ){
    pexit("SSL_set_fd");
  }
   
  /* Make SSL handshake with server */
  ret = SSL_connect(ssl);
  if ( ret == 0 ){
    pexit("SSL_connect failed with 0");
  }else if ( ret < 0 ){
    pexit("SSL_connect failed with <0");
  }
  
  printf("SSL client connection is up\n\n\n");
  fflush(NULL);
 
  if ( protocol(ssl,"daniel","gaisler") ){
#else
  printf("Client connection is up\n\n\n");
  fflush(NULL);

  if ( protocol(sock,"daniel","gaisler") ){
#endif
    ;
  }

#ifdef USE_SSL
  SSL_CTX_free(ctx);
#endif
  close(sock);
  return 0;
}
